#pragma once
#include<iostream>
#include<assert.h>
#include"vector"
#include"iterator.h"
#include"CMalloc.h"
#include<functional>

namespace STL {

	template<typename T,typename Allocator=CMP::TCMemAllocator>
	class list;//����������ֹlist_iterator�Ҳ���listģ��

	template<typename T>
	struct list_node {
		T data;
		list_node* prev;
		list_node* next;

		list_node(const T& x = T(), list_node* PREV = nullptr, list_node* NEXT = nullptr) :data(x), prev(PREV), next(NEXT) {}
	};
	


	template<typename T, class ref, class ptr>
	struct list_iterator {
		typedef list_iterator<T, ref, ptr> self;
		typedef list_node<T> node;

		list_iterator(node* node = nullptr) :_pnode(node) {}
		template<class IT>
		list_iterator(const IT& it) :_pnode(it._pnode) {}//֧��iterator����ת��const_iterator
		                                                //֧����ʽ����ת������Ӧ�ĵ�����operator=����д��

		self& operator++() {
			_pnode = _pnode->next;
			return *this;
		}
		self operator++(int) {
			self temp = _pnode;
			_pnode = _pnode->next;
			return temp;
		}
		self& operator--() {
			_pnode = _pnode->prev;
			return *this;
		}
		self operator--(int) {
			self temp = _pnode;
			_pnode = _pnode->prev;
			return temp;
		}

		ref operator*() {
			return _pnode->data;
		}

		ptr operator->() {//����ptrָ��
			return &(operator*());//����node��data�ǽṹ�壬��int a1��int a2
		}//it->a1 �������� it.operator->() -> a1������Ҫ����ptr��ֻ����������Ϊ�˺ÿ����⴦���ˡ�ֻ��һ�� ->

		bool operator==(const self& it) {
			return _pnode == it._pnode;
		}
		bool operator!=(const self& it) {
			return _pnode != it._pnode;
		}

		node* _pnode;
	};



	template<typename T,typename Allocator>
	void swap(list<T, Allocator>& L1, list<T, Allocator>& L2) {
		L1.swap(L2);
	}

	template<typename T,typename Allocator>
	class list {
	public:
		typedef list_node<T> node;
		typedef list_iterator<T, T&, T*> iterator;
		typedef list_iterator<T, const T&, const T*> const_iterator;
		typedef reverseiterator<iterator, T&, T*> reverse_iterator;
		typedef reverseiterator<iterator, const T&, const T*> const_reverse_iterator;


		list() {
			empty_initialize();
		}
		list(const list& L) {
			empty_initialize();
			insert(end(), L.begin(), L.end());
		}
		list(initializer_list<T> L) {//������һ�������{ }�ڴ��������ṩbegin��endָ�롣
			empty_initialize();
			insert(end(), L.begin(), L.end());//���������캯��֧����ʽ����ת����
		}                                    //֧�� list<int> L = {1,2,3,4,5} ��д��
		~list() {
			erase(begin(), end());
		}

		list& operator=(const list& L) {
			if (L._head != _head) {
				list temp = L;
				swap(*this, temp);
			}
			return *this;
		}

		////////////////////////////////////////////////��ɾ���///////////////////////////////////////////////////////
		T& front() {
			assert(_size != 0);
			return _head->next->data;
		}
		T& back() {
			assert(_size != 0);
			return _head->prev->data;
		}
		template <class InputIterator>
		void assign(InputIterator first, InputIterator last) {
			clear();
			insert(end(), first, last);
		}
		void assign(size_t n, const T& val) {
			clear();
			insert(end(), n, val);
		}
		void assign(initializer_list<T> L) {
			clear();
			insert(end(), L.begin(), L.end());
		}


		void resize(size_t n) {
			if (n <= _size) {
				iterator del_begin = end();
				size_t cnt = _size - n;
				while (cnt--) {
					del_begin--;
				}
				erase(del_begin, end());
			}
			else {
				insert(end(), n - _size, T());
			}
		}

		void clear() {
			erase(begin(), end());
		}

		iterator insert(iterator pos, const T& x) {
			return insert(pos, 1, x);
		}
		iterator insert(iterator pos, int n, const T& x) {
			assert(n >= 0);
			return insert(pos, (size_t)n, x);
		}
		iterator insert(iterator pos, size_t n, const T& x) {
			node* insert_pos = pos._pnode;
			node* prev = insert_pos->prev;
			node* temp; _size += n;
			while (n--) {
				//temp = new node(x);
				temp = (node*)Allocator::Alloc(sizeof(node));
				new (temp) node(x);

				link_node(insert_pos->prev, temp);
				link_node(temp, insert_pos);
			}
			return prev->next;
		}
		template<class InputIterator>
		iterator insert(iterator pos, InputIterator first, InputIterator last) {
			node* insert_pos = pos._pnode;
			node* prev = insert_pos->prev;
			node* temp;
			size_t cnt = 0;
			while (first != last) {
				//temp = new node(*first);
				temp = (node*)Allocator::Alloc(sizeof(node));
				new (temp) node(*first);

				link_node(insert_pos->prev, temp);
				link_node(temp, insert_pos);
				first++; cnt++;
			}
			_size += cnt;
			return prev->next;
		}

		template<typename compare>
		iterator insert_ordered(const T& x ,compare) {
			iterator it = begin();
			while (it!= end() && *it <= x) {
				++it;
			}
			insert(it, x);
			return --it;
		}

		iterator erase(iterator pos) {
			iterator end = pos;
			return erase(pos, ++end);
		}
		iterator erase(iterator first, iterator last) {
			if (first == last)return last;
			node* left = first._pnode->prev;
			node* right = last._pnode;

			size_t cnt = 0;
			node* p = first._pnode;
			node* q = p->next;
			while (p != last._pnode) {
				assert(p != _head);
				//delete p;  
				Allocator::Free(p);
				cnt++;
				p = q;
				q = q->next;
			}
			_size -= cnt;
			link_node(left, right);

			return right;
		}

		void push_back(const T& x) {
			insert(end(), x);
		}
		void push_front(const T& x) {
			insert(begin(), x);
		}
		void pop_back(const T& x) {
			erase(--end());
		}
		void pop_front(const T& x) {
			erase(begin());
		}
		void splice(const_iterator position, list& list) {
			splice(position, list, list.cbegin(), list.cend());
		}
		void splice(const_iterator position, list& list, const_iterator i) {
			auto j = i; ++j;
			splice(position, list, i, j);
		}
		void splice(const_iterator position, list& list, const_iterator first, const_iterator last) {
			assert(first != last && first!=position);
			const_iterator pre = position; --pre;
			size_t cnt = 0;
			for (const_iterator it = first; it != last; ++it) {
				assert(it._pnode != list.cend()._pnode);
				cnt++;
			}

			const_iterator L = first--;
			const_iterator R = last; --R;
			link_node(first, last);

			link_node(pre, L);
			link_node(R, position);

			_size += cnt;
		}
		void remove(const T& val) {
			iterator it = begin();
			while (it != end()) {
				if (*it == val) {
					it = erase(it);
				}
				else {
					++it;
				}
			}
		}

		template <class Predicate>
		void remove_if(Predicate pred) {
			iterator it = begin();
			while (it != end()) {
				if (pred(*it)) {
					it = erase(it);
				}
				else {
					++it;
				}
			}
		}

		template<class compare>
		void sort(compare cmp) {
			iterator be = begin();
			mergesort(be, _size, cmp);
		}
		                        //0                   5                   10  11
		template<class compare>//857,521,250,911,361,438,985,211,110,666,369
		void mergesort(iterator& pos ,size_t N ,compare cmp) {//Ҳ���봫����
			if (N < 2)return;
			iterator mid = pos;
			size_t left = N / 2;
			size_t right = N - left;
			for (size_t i = 0; i < left; i++) {
				++mid;
			}
			
			mergesort(pos,left, cmp);
			mergesort(mid, right, cmp);
			merge(pos, left, *this, mid, right, cmp);//ָ�봫����,��֤merge��λ�򲻱�
			//����ָ�������ԣ���merge��midָ���λ��Ŀ��ܲ���֮ǰ��mid��λ��
			//print_container(*this);
		}

		template <class Compare>
		void merge(list& x, Compare cmp) {
			merge(begin(), _size, x, x.begin(), x._size, cmp);
		}

		template <class Compare>//merge��Ϊ����λ�򲻱�,pָ��ϲ�������1��Ԫ�أ�qָ���N+1��
		void merge(iterator& P, size_t N,list&  L, iterator& Q, size_t M, Compare cmp) {
			iterator p = P, q = Q;

			size_t n = 0 ,m = 0;//_head  p          q  
			iterator pren = p;  --pren;//2 4 6 8 10 1 3 5 7 9 
			iterator prem = q;  --prem;//1 3 5 7 9  2 4 6 8 10

			list temp;
			iterator last = temp._head;
			while (n != N && m != M) {
				assert(p != end() && q != L.end());
				assert(p != Q && q != P);//��ֹͬһ�����ϲ�ʱǰ�������غ�
				if ( cmp(*p,*q) ) {//�����������غϣ�����P��Q����,�ڶ�Ӧ��p��qָ��֮��Ľڵ��next��û�б��޸ĵġ��ر��,
					link_node(last, p);//�������佻�㴦�ڵ��next���ܵ�����һ�����䡣��������P��Q�ĸ���ǰһ�����䣬
					++n; ++p;         //���Ӧָ�붼�ܸ���p != Q && q != P�����ж��Ƿ��غ�
				}
				else {
					link_node(last, q);
					++m; ++q;
				}
				++last;
			}
			while (n != N) {
				assert(p != end());
				link_node(last, p);
				++n; ++p;
				++last;
			}
			while (m != M) {
				assert(q != L.end());
				link_node(last, q);
				++m; ++q;
				++last;
			}
			link_node(last, temp._head);

			//�ų���ͬ������ͬ�������
			if (*this != L ||(p!=Q && q!=P)) {
				link_node(prem, q);
				link_node(pren, p);
				splice(pren, temp);
			}
			else {//ֻʣ��������
				if (p == Q) {//P������Q����ǰ��
					link_node(pren, q);
					splice(++pren, temp);
				}
				if (q == P) {//Q������P����ǰ��
					link_node(prem, p);
					splice(++prem, temp);
				}
			}

			P = *P < *Q ? P : Q;
			Q = P;
			for (size_t i = 0; i < N; i++) {
				++Q;
			}

			_size += N;
			L._size -= M;
		}

		void unique() {
			iterator mom = begin();
			iterator son;

			for (son = mom; son != end(); son++) {
				if (*son != *mom) {
					mom = erase(++mom, son);
				}
			}
			 
			auto& temp = *(mom++);//������������
			if (temp == *mom)erase(mom, son);
		}
		void reverse() {
			node* pre = _head;
			node* reverse = begin()._pnode;
			node* next = reverse;

			while (reverse!=_head) {
				next = reverse->next;
				link_node(reverse ,pre);//ע�����Ⱥ����

				pre = reverse; 
				reverse = next;
				next = next->next;
			}
			link_node(_head, pre);
		}
		////////////////////////////////////////////////��������///////////////////////////////////////////////////////
		iterator begin() {
			return _head->next;
		}
		iterator end() {
			return _head;
		}
		iterator begin() const {
			return _head->next;
		}
		iterator end() const {
			return _head;
		}
		const_iterator cbegin() {
			return _head->next;
		}
		const_iterator cend() {
			return _head;
		}
		reverse_iterator rbegin() {
			return end();
		}
		reverse_iterator rend() {
			return begin();
		}
		const_reverse_iterator crbegin()const {
			return end();
		}
		const_reverse_iterator crend() const {
			return begin();
		}

		void swap(list& L) {
			std::swap(_head, L._head);
			std::swap(_size, L._size);
		}

		size_t size() {
			return _size;
		}
		bool empty() {
			return _size == 0;
		}

		bool operator==(const list& L) {
			return _head == L._head;
		}
		bool operator!=(const list& L) {
			return _head != L._head;
		}
	private:
		void link_node(node* first, node* second) {//ע�����Ⱥ����
			first->next = second;	second->prev = first;
		}
		void link_node(iterator first, iterator second) {
			link_node(first._pnode, second._pnode);
		}
		void link_node(const_iterator first, const_iterator second) {
			link_node(first._pnode, second._pnode);
		}
		void empty_initialize() {
			//_head = new node;
			_head = (node*)Allocator::Alloc(sizeof(node));
			new (_head)node();

			_head->prev = _head->next = _head;
			_size = 0;
		}
	private:
		node* _head;
		size_t _size;
	};
	/////////////////////////////////////////end_of_class////////////////////////////////////////////////////////





	/*template<class container>
	void print_container(const container& v) {
		for (auto& e : v) {
			cout << e << ' ';
		}
		cout << endl;
	}*/


	void test01_L() {
		STL::list<int> L1;
		L1.push_back(1);
		L1.push_back(2);
		L1.push_back(3);
		L1.push_back(4);
		L1.push_back(5);

		print_container(L1);
		L1.clear();
		print_container(L1);
	}
	void test02_L()
	{
		STL::list<int> L1;
		std::vector<int> v = { 1,2,3,4,5 };

		list<int>::iterator it = L1.insert(L1.begin(), v.begin(), v.end());
		print_container(L1);
		cout << "size:" << L1.size() << endl;
		it = L1.insert(L1.begin(), 1, 10);
		print_container(L1);
		cout << "size:" << L1.size() << endl;

		it++;
		list<int>::iterator t = it;
		t++; t++;
		it = L1.erase(it, ++t);
		print_container(L1);
		cout << *it << endl;
		cout << "size:" << L1.size() << endl;

		it = L1.erase(it);
		print_container(L1);
		cout << *it << endl;

		cout << "size:" << L1.size() << endl;
	}

	void test03_L()
	{
		STL::list<int> L1;
		std::vector<int> v = { 1,2,3,4,5 };
		list<int>::iterator it = L1.insert(L1.begin(), v.begin(), v.end());
		print_container(L1);

		it = L1.insert(L1.end(), v.begin(), v.end());
		print_container(L1);
		cout << L1.size();
	}
	void test04_L()
	{
		STL::list<int> L1;
		std::vector<int> v = { 1,2,3,4,5 };
		list<int>::iterator it = L1.insert(L1.begin(), v.begin(), v.end());
		print_container(L1);

		L1.push_back(0);
		L1.push_front(0);
		print_container(L1);
		L1.pop_back(0);
		L1.pop_front(0);
		print_container(L1);

		L1.resize(3);
		print_container(L1);
		cout << "size:" << L1.size() << endl;
		L1.resize(5);
		print_container(L1);
		cout << "size:" << L1.size() << endl;

		L1.clear();
		print_container(L1);
		cout << "size:" << L1.size() << endl;
	}
	void test05_L() {
		STL::list<int> L1;
		std::vector<int> v = { 1,2,3,4,5 };
		list<int>::iterator it = L1.insert(L1.begin(), v.begin(), v.end());
		print_container(L1);

		std::vector<int> v2 = { 5,4,3,2,1 };
		STL::list<int> L2 = L1;
		print_container(L2);

		L2.assign(v2.begin(), v2.end());
		print_container(L2);


	}

	struct A {
		int a;
		int b;
	};

	void test06_L() {
		STL::list<int> L1 = { 1,2,3,4,5 };//
		print_container(L1);

		auto it = L1.rbegin();
		while (it != L1.rend()) {
			cout << *it << ' ';
			(*it)++;
			it++;
		}
		cout << endl;

		print_container(L1);

		STL::list<A> L2 = { {1,2},{2,3 } };
		auto rit = L2.rbegin();
		cout << rit->b;

	}

	void test07_L() {
		STL::list<int> L = { 1,2,3,4,5,6 };
		STL::list<int> R = L;

		auto it = L.cbegin(); ++it; ++it; ++it;
		auto ti = it; ++ti; ++ti; ++ti;
		L.splice(L.cbegin(), L, it, ti);

		print_container(L);
		L.splice(L.cbegin(), L, --L.cend());
		print_container(L);
		print_container(R);
		L.splice(L.cbegin(), R);
		print_container(L);
		print_container(R);

	}

	void test08_L() {
		STL::list<int> N = { 7,7,6,6,5,4,3,2,1 };
		N.reverse();
		print_container(N);
		N.unique();
		print_container(N);

		cout << endl;
		
		STL::list<int> M = { 1,1,2,2,2,3,3,3,4,5,6,6 };
		M.reverse();
		print_container(M);
		M.unique();
		print_container(M);

		cout << endl;

		N.splice(N.cend(), M);
		print_container(N);
		print_container(M);

		N.reverse();
		STL::list<int>::iterator it = N.begin();
		for( ;*it!=7;it++){}
		it++;
		N.remove(7);
		print_container(N);
		N.insert(it, 2,7);
		print_container(N);

		it--;
		STL::list<int>::const_iterator ti = it;
		STL::list<int>::const_iterator itti;
		itti = it;
		STL::list<int> T = { 8,9,8 };
		N.splice(itti, T);
		print_container(N);
		cout << N.size() << endl;

		STL::list<int>::reverse_iterator rit = N.rbegin();
		STL::list<int>::const_reverse_iterator crit = rit;
		STL::list<int>::const_reverse_iterator ccrrit;
		ccrrit = rit;
		while (crit != N.crend()) {
			cout << *crit << ' ';
			++crit;
		}
		cout << endl;
	}


	template<typename T>
	struct jishu {
		bool operator()(const T& x) {
			return x % 2 == 1;
		}
	};
	template<typename T>
	struct oushu {
		bool operator()(const T& x) {
			return x % 2 == 0;
		}
	};

	void test09_L() {
		STL::list<int> L = { 1,2,4,5,6,7,8,9 };
		
		auto it = L.insert_ordered(3, less<int>());
		print_container(L);
		cout << *it << endl;

		it = L.insert_ordered(10, less<int>());
		print_container(L);
		cout << *it;
	}
	void test10_L() {
		STL::list<int> L = { 1,2,3,4,5,6,7,8,9,10 };
		STL::list<int> R = L;

		L.remove_if(oushu<int>());
		print_container(L);
		R.remove_if(jishu<int>());
		print_container(R);

		cout << endl;

		/*L.merge(L.begin(), L.size(), R, R.begin(), R.size(),less<int>());
		print_container(L);
		print_container(R);*/

		size_t n = L.size();
		size_t m = R.size();
		STL::list<int>::iterator it = L.end(); --it;
		L.splice(L.end(),R);
		print_container(L);
		cout << *it << endl;

		auto be = L.begin();
		L.splice(L.cbegin(), L,++it, L.cend());
		print_container(L);
		L.merge(be , n, L, it, m,less<int>());
		print_container(L);
		cout << *be << ' ' << *it << endl;

	}
	void test11_L() {
		STL::list<int> L = { 857,521,250,911,361,438,985,211,110,666,369 };

		/*STL::list<int>::iterator a = L.begin();
		STL::list<int>::iterator b = a; ++b;
		L.merge(a, 1, L, b, 1, less<int>());
		print_container(L);*/
		L.sort(less<int>());
		print_container(L);

	}

	using func_t = std::function<void()>;
	void test_list() {
		std::vector<func_t> v;
		v.push_back(test01_L);
		v.push_back(test02_L);
		v.push_back(test03_L);
		v.push_back(test04_L);
		v.push_back(test05_L);
		v.push_back(test06_L);
		v.push_back(test07_L);
		v.push_back(test08_L);
		v.push_back(test09_L);
		v.push_back(test10_L);
		v.push_back(test11_L);

		for (int i = 0; i < v.size(); i++) {
			Header(i + 1);
			v[i]();
		}


	}



}