#pragma once

template<class iterator, class ref, class ptr>
struct  reverseiterator {
	typedef reverseiterator<iterator, ref, ptr> self;

	reverseiterator(iterator it=iterator()) :_rit(it) {}
	template<class RIT>
	reverseiterator(const RIT& rit) :_rit(rit._rit){}//֧��iterator����ת��const_iterator
		                                            //֧����ʽ����ת������Ӧ�ĵ�����operator=����д��



	bool operator !=(const self& it) {
		return _rit != it._rit;
	}
	bool operator ==(const self& it) {
		return _rit == it._rit;
	}

	ref operator*() {
		self temp = *this;
		--(temp._rit);
		return *(temp._rit);
	}

	ptr operator->() {
		return &(operator*());
	}

	self operator++(int) {
		self temp = *this;
		--_rit;
		return temp;
	}
	self& operator++() {
		--_rit;
		return *this;
	}
	self operator--(int) {
		self temp = *this;
		++_rit;
		return temp;
	}
	self& operator--() {
		++_rit;
		return *this;
	}



	iterator _rit;
};
